from ase.io import read,write
import sys

def main(prefix):
    # input file
    
    frame = read(prefix,format='lammps-data',units="metal",style="atomic")
    frame.write(prefix+".xyz")
if __name__ == '__main__':
    main(sys.argv[1])
