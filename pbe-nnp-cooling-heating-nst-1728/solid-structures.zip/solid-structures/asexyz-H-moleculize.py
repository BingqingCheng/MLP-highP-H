from ase import Atoms
from ase.io import read,write
import numpy as np
import sys

def moleculize(frame):
    h = frame.get_cell()
    ih = np.linalg.inv(h)
    natoms = len(frame.get_positions())
    print("a total of ", natoms, " atoms")
    q = frame.get_positions()
    dmat = np.zeros((natoms,natoms))

    # computes all distances, with PBC
    for i in range(natoms):
        dq = (q - q[i]).T
        dq = np.dot(ih, dq)
        dq -= np.round(dq)
        dq = np.dot(h, dq)
        d2 = (dq*dq).sum(axis=0)
        dmat[i,:] = d2
        dmat[i,i] = 1e100

    # builds pairs (not super-efficient but hey....)
    qmol = np.zeros((natoms/2,3))
    dmol = np.zeros(natoms/2)
    for i in range(natoms/2):
        jkmin = np.where(dmat == np.amin(dmat))
        j = jkmin[0][0]
        k = jkmin[1][0]
        djk = np.sqrt(dmat[j,k])
        dmat[:,j] = 1e100
        dmat[:,k] = 1e100
        dmat[j,:] = 1e100
        dmat[k,:] = 1e100   # "cross-out" these two atoms

        dq = q[j]-q[k]
        dq = np.dot(ih, dq)
        dq -= np.round(dq)
        dq = np.dot(h, dq)
        qmol[i] = q[k] + dq*0.5
        dmol[i] = djk

    #frame.set_positions(qmol)
    #frame.numbers = np.ones(len(qmol))
    newframe = Atoms(positions=qmol, cell=h, pbc=[True, True, True])
    newframe.set_atomic_numbers(np.ones(len(qmol)))
    return newframe

def main(prefix):
    # input file
    
    frame = read(prefix)
    newframe = moleculize(frame)
    newframe.write("moleculerized-"+prefix)

if __name__ == '__main__':
    main(sys.argv[1])



